# Лабораторная работа 6: тестирование и оценка прототипа

Проверяется прототип GremlinDrive из ЛР5: навигация ЛР2, UC-01–UC-05 ЛР3, контракт ЛР4. [Отчёт PDF](lab6-report.pdf), [исходник отчёта](report/report.tex), [анкеты](QUESTIONNAIRES.md), [дерево](tree.html), [формы](forms.html).

## Что сделано

- 210 синтетических попыток для 7 задач на web и mobile;
- 30 анкет SUS;
- 120 синтетических выборов дерева и 120 оценок ожиданий;
- два чек-листа по 30 пунктов: [web](data/checklist-web.csv), [mobile](data/checklist-mobile.csv);
- реестр из 8 проблем: [issues.csv](data/issues.csv);
- 12 моделей GOMS и 3 мобильные KLM/TLM;
- сводка: [summary.json](data/summary.json), происхождение: [PROVENANCE.json](data/PROVENANCE.json).

## Границы

Данные синтетические: `data_origin=synthetic`, `human_participants=0`. Реальных сессий с участниками не было. **Treejack не запускался**: подготовлены деревья `data/tree-import.txt`, `data/tree-import-mobile.txt` и задания C1–C4, но нет ссылки на исследование и экспорта сервиса. Локальный `tree.html` — демонстрация, а не Treejack.

## Файлы

| Файл | Назначение |
|---|---|
| `report/report.tex` | LaTeX-исходник отчёта |
| `data/performance.csv` | Успех, время, ошибки, SEQ |
| `data/sus.csv` | 30 анкет SUS |
| `data/tree_results.csv` | Офлайн-сортировка, `success/direct/backtracks` |
| `data/expectancy.csv` | Ожидания E1–E4 |
| `data/checklist-web.csv`, `data/checklist-mobile.csv` | Чек-листы |
| `data/issues.csv` | Issues-based metrics |
| `data/goms.csv` | 12 моделей GOMS |
| `data/mobile_klm.csv` | 3 модели KLM/TLM |
| `data/layout-checks.json` | 11 проверок viewport |
| `data/prototype-checks.json` | Фактические проверки прототипа |

Публичная страница: https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab6/. Архив исходников: `lab6-source.zip` на странице.
