# Лабораторная работа 4

GremlinDrive. Стили интеграции программных систем и проектирование API. Работа продолжает требования и модели ЛР3, подготовленные Матвеем Вержбибой в коммите 392a849. В ЛР4 Александр Сытин уточнил требования к API, физическую схему PostgreSQL, контракт запросов, mock-окружение и MCP MVP.

## Материалы

| Задание | Результат |
|---|---|
| 1 | [Модель требований и 19 вариантов использования](requirements.md), [трассировка](traceability.json) |
| 2 | [Логическая схема](database/logical-model.md), [PostgreSQL DDL](database/schema.sql), [PlantUML](diagrams) |
| 3 | [Маршруты и их связь с UC](api-design.md), [OpenAPI](openapi.json) |
| 4 | [Коллекция Bruno](bruno), [коллекция Postman](postman_collection.json), [проверки контракта](evidence/contract-tests.json) |
| 5 | [Описание MCP](mcp.md), [исходники и запуск](runtime/README.md), [JSON-схемы и протокол](evidence/mcp-protocol.json) |
| 6 | [Инфраструктура и план](infrastructure.md), [Compose](compose.yaml), [CI](../../../../.github/workflows/lab4.yml) |

[Отчёт PDF](lab4-report.pdf). [Материалы на сайте проекта](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/).

## Быстрый запуск

Из каталога docs/labs/lab4:

```bash
docker compose up -d --build api database contract web
```

Документация доступна на http://127.0.0.1:8045, интерактивный Swagger UI stateful mock - на http://127.0.0.1:8044/docs, полный контракт Prism - на http://127.0.0.1:4010. База PostgreSQL внутри сети Compose проверяет физическую схему. Stateful mock использует SQLite в отдельном volume. Внутри этого учебного стенда база PostgreSQL не является источником данных FastAPI.

Для локального запуска Python и MCP:

```bash
cd runtime
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/pytest -q
.venv/bin/python test_mcp.py
.venv/bin/uvicorn api:app --host 127.0.0.1 --port 8044
```

В отдельном терминале из runtime можно запустить `.venv/bin/python mcp_server.py` через MCP-клиент или Inspector. По умолчанию сервер работает от учебного пользователя Артём. Переменная GREMLIN_DB задаёт общий путь к SQLite при одновременной демонстрации REST и MCP.

```bash
npx --yes @usebruno/cli run --env contract
```

Команда запускается из каталога bruno и проверяет весь контракт. Stateful-окружение используется только для операций с пометкой stateful-mock; зависимые id и токены берутся из фактических ответов. Для повторяемой проверки бизнес-сценариев предназначены pytest-тесты, создающие временную базу.

## Демонстрационные данные

У mock-сервиса есть публичные учебные токены lab-owner-token, lab-reader-token, lab-admin-token и lab-outsider-token. Они предназначены только для изолированного стенда с тестовыми данными. Владельцу принадлежит папка Учёба и файл Лабораторная.txt, читатель имеет доступ на просмотр. Секреты портала, GitHub и реальные файлы пользователей стенд не использует.

## Границы результата

OpenAPI описывает 52 операции. Из них 21 работает с состоянием SQLite, остальные симулируются Prism. Регистрация, TOTP, S3, передача бинарных частей, SMTP, LDAP и push описаны контрактом для следующего этапа. MCP MVP реализован и проверен полностью в своей заявленной области из семи инструментов, трёх ресурсов, одного шаблона ресурса и двух промптов.

Задание 6 выполнено в части локального стенда, Dockerfile, Compose, автоматических тестов, генерации OpenAPI и workflow CI. Публикация backend в Render/Vercel и подключение SonarCloud требуют отдельного аккаунта и настроек сервиса; успешный облачный деплой и Quality Gate в этой работе не заявлены. Состояние wiki и проверки CI фиксируются отдельно после публикации.
