import re
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'diagrams'
STYLE='''@startuml
!pragma layout smetana
skinparam backgroundColor white
skinparam defaultFontName "DejaVu Sans"
skinparam defaultFontSize 15
skinparam shadowing false
skinparam roundcorner 5
skinparam linetype ortho
skinparam classBackgroundColor #F4F7FA
skinparam classBorderColor #49647A
hide circle
'''
sql=(ROOT/'database/schema.sql').read_text()
tables={}
edges=[]
for name,body in re.findall(r'CREATE TABLE (\w+) \((.*?)\n\);',sql,re.DOTALL):
    fields=[]
    for line in body.splitlines():
        match=re.match(r'\s*(\w+)\s+(uuid|smallint|bigint|integer|varchar\(\d+\)|char\(\d+\)|text|inet|timestamptz|boolean|date)(?=\s|,)(.*)',line)
        if not match:
            continue
        field,typ,rest=match.groups()
        key='PK' if 'PRIMARY KEY' in rest else ('FK' if 'REFERENCES' in rest else '')
        if field in {'id'}:
            key='PK'
        if name=='quotas' and field=='user_id':
            key='PK,FK'
        if name=='files' and field=='folder_id':
            key='FK'
        if (name=='user_roles' and field in {'user_id','role_id'}) or (name=='folder_members' and field in {'folder_id','user_id'}):
            key='PK,FK'
        fields.append((field,typ,key))
        target=re.search(r'REFERENCES (\w+)',rest)
        if target:
            edges.append((target[1],name,field))
    tables[name]=fields
edges.extend([('folders','files','folder_id'),('folders','folders','parent_id')])


def physical(name,selected):
    text=STYLE+f'title {name}\n'
    for table in selected:
        text+=f'entity "{table}" as {table} {{\n'
        for field,typ,key in tables[table]:
            text+=f'  {"* " if "PK" in key else ""}{field} : {typ}'+(f' <<{key}>>' if key else '')+'\n'
        text+='}\n'
    for a,b,col in set(edges):
        if a in selected and b in selected:
            text+=f'{a} '+('||--o| ' if b=='quotas' else '||--o{ ')+f'{b} : {col}\n'
    return text+'@enduml\n'


(OUT/'physical.puml').write_text(physical('GremlinDrive PostgreSQL 16',list(tables)))
for filename,title,names in [
 ('identity','Identity and administration',['users','roles','user_roles','sessions','quotas','audit_records','access_requests']),
 ('storage','Files and uploads',['users','folders','files','file_versions','upload_sessions']),
 ('sharing','Sharing and collaboration',['files','folders','share_links','access_permissions','folder_members','invitations','comments','notifications'])]:
    (OUT/f'physical-{filename}.puml').write_text(physical(title,names))
logical=STYLE+'title GremlinDrive logical data model\n'
for table,fields in tables.items():
    logical+=f'entity "{table}" as {table} {{\n'+'\n'.join(f'  {f}'+(f' <<{k}>>' if k else '') for f,t,k in fields)+'\n}\n'
for a,b,col in set(edges):
    logical+=f'{a} '+('||--o| ' if b=='quotas' else '||--o{ ')+f'{b} : {col}\n'
(OUT/'logical.puml').write_text(logical+'@enduml\n')
(OUT/'requirements.puml').write_text(STYLE+'''left to right direction
title Actor to User Story to Use Case
actor "Пользователь" as user
actor "Гость" as guest
actor "Владелец папки" as owner
actor "Администратор" as admin
rectangle "US-07 Загрузить материалы" as us7
rectangle "US-03 Передать защищённой ссылкой" as us3
rectangle "US-04 Скачать без регистрации" as us4
rectangle "US-05 Пригласить команду" as us5
rectangle "US-09 Управлять квотами" as us9
usecase "UC-05 Загрузка частями" as uc5
usecase "UC-09 Создание и отзыв ссылки" as uc9
usecase "UC-10 Гостевой доступ" as uc10
usecase "UC-11 Приглашение участника" as uc11
usecase "UC-15 Управление пользователями" as uc15
user --> us7
user --> us3
guest --> us4
owner --> us5
admin --> us9
us7 --> uc5
us3 --> uc9
us4 --> uc10
us5 --> uc11
us9 --> uc15
@enduml
''')
(OUT/'mcp.puml').write_text(STYLE+r'''left to right direction
title GremlinDrive MCP MVP
actor "Пользователь" as user
rectangle "LLM host / MCP Inspector" as host
rectangle "MCP Python SDK\nstdio / JSON-RPC" as mcp
rectangle "Tools\n7 типизированных действий" as tools
rectangle "Resources\npolicy, quota, files" as resources
rectangle "Prompts\nshare_file_safely\nreview_storage" as prompts
rectangle "store.py\nACL + валидация + транзакции" as domain
rectangle "FastAPI\nStateful REST mock" as api
database "SQLite demo.db\nучебные данные" as db
user --> host
host --> mcp
mcp --> tools
mcp --> resources
mcp --> prompts
tools --> domain
resources --> domain
api --> domain
domain --> db
note bottom of domain
  Личность задаёт сервер.
  user_id не принимается от LLM.
  Пароли и токены не пишутся в аудит.
end note
@enduml
''')
(OUT/'infrastructure.puml').write_text(STYLE+r'''title Lab 4 local Docker environment
node "Developer computer / 127.0.0.1" {
  rectangle "Browser / Bruno\nPostman / Inspector" as clients
  node "Docker Compose network" {
    rectangle "nginx :8045\nHTML documentation" as web
    rectangle "Prism :4010\n52 contract operations" as prism
    rectangle "FastAPI :8044\nstateful subset" as api
    database "SQLite volume\nMCP fixture" as sqlite
    database "PostgreSQL 16\nDDL validation" as postgres
    rectangle "SonarQube\noptional quality profile" as sonar
  }
  rectangle "MCP stdio server" as mcp
}
clients --> web
clients --> prism
clients --> api
clients --> mcp
api --> sqlite
mcp --> sqlite : shared store in local mode
note bottom of postgres
  Целевая физическая схема.
  SQLite mock не выдаётся за PostgreSQL backend.
end note
@enduml
''')
lines=['# Логическая схема базы данных','',
 'Модель продолжает 16 сущностей ЛР3. Добавлена upload_sessions для загрузки частями и идемпотентного завершения. Содержимое файлов хранится в S3, в таблицах остаются метаданные.','']
for table,fields in tables.items():
    lines+=['## '+table,'',', '.join(f'`{f}`'+(f' ({k})' if k else '') for f,t,k in fields)+'.','']
lines+=['## Связи','']+[f'{a}.id → {b}.{col} '+('(1:0..1).' if b=='quotas' else '(1:N).')+'\n' for a,b,col in sorted(set(edges))]
(ROOT/'database/logical-model.md').write_text('\n'.join(lines)+'\n')
print('Generated',len(tables),'tables and 8 diagrams')
