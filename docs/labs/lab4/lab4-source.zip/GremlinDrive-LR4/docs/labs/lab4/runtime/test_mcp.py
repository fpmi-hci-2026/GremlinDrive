"""Real MCP stdio integration: initialize, discovery, resources, prompts, calls."""
import asyncio
import json
import os
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

import store


async def protocol_check(db, user=store.OWNER):
    env = {**os.environ, "GREMLIN_DB": str(db), "GREMLIN_USER_ID": user}
    params = StdioServerParameters(command=sys.executable,
        args=[str(Path(__file__).with_name("mcp_server.py"))], env=env)
    async with stdio_client(params) as (read, write):  # noqa: SIM117 - session depends on transport
        async with ClientSession(read, write) as session:
            initialized = await session.initialize()
            tools = await session.list_tools()
            assert len(tools.tools) == 7
            resources = await session.list_resources()
            assert len(resources.resources) == 3
            templates = await session.list_resource_templates()
            assert len(templates.resourceTemplates) == 1
            prompts = await session.list_prompts()
            assert len(prompts.prompts) == 2
            files = await session.call_tool("list_files", {})
            assert not files.isError
            result = await session.call_tool("get_file", {"file_id": store.FILE})
            assert not result.isError
            policy = await session.read_resource("gremlin://policy")
            assert "SQLite" in policy.contents[0].text
            await session.read_resource(f"gremlin://files/{store.FILE}")
            await session.read_resource("gremlin://quota")
            await session.read_resource("gremlin://files/recent")
            prompt = await session.get_prompt("share_file_safely", {"filename": "Лабораторная.txt"})
            assert len(prompt.messages) == 1
            await session.get_prompt("review_storage", {})
            invalid = await session.call_tool("trash_file", {"file_id": store.FILE, "confirm": False})
            assert invalid.isError
            malformed = await session.call_tool("get_file", {"file_id": "not-a-uuid"})
            assert malformed.isError
            link = await session.call_tool("create_share_link", {"file_id": store.FILE,
                "password": "laboratory123", "expires_in_days": 7})
            if user == store.READER:
                assert link.isError
                return {"reader_publish_denied": True}
            assert not link.isError
            link_data = json.loads(link.content[0].text)
            revoked = await session.call_tool("revoke_share_link", {"share_id": link_data["id"]})
            assert not revoked.isError
            folder = await session.call_tool("create_folder", {"name": "MCP отчёты"})
            assert not folder.isError
            trashed = await session.call_tool("trash_file", {"file_id": store.FILE, "confirm": True})
            assert not trashed.isError
            restored = await session.call_tool("restore_file", {"file_id": store.FILE})
            assert not restored.isError
            return {"protocol_version": initialized.protocolVersion,
                "tools": [t.model_dump(mode="json") for t in tools.tools],
                "resources": [r.model_dump(mode="json") for r in resources.resources],
                "resource_templates": [r.model_dump(mode="json") for r in templates.resourceTemplates],
                "prompts": [p.model_dump(mode="json") for p in prompts.prompts],
                "verified": ["initialize", "tools/list", "resources/list", "resources/templates/list",
                    "prompts/list", "resources/read", "prompts/get", "tools/call",
                    "invalid UUID rejected", "confirm=false rejected", "CRUD lifecycle"]}


def test_mcp_owner(tmp_path):
    asyncio.run(protocol_check(tmp_path / "owner.db"))


def test_mcp_reader_cannot_publish(tmp_path):
    asyncio.run(protocol_check(tmp_path / "reader.db", store.READER))


if __name__ == "__main__":
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        result = asyncio.run(protocol_check(Path(tmp) / "protocol.db"))
        result.update(asyncio.run(protocol_check(Path(tmp) / "reader.db", store.READER)))
    dest = Path(__file__).resolve().parent.parent / "evidence" / "mcp-protocol.json"
    dest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print("MCP stdio discovery, 7 tools, 3 resources, 1 template, 2 prompts: PASS")
