# Лабораторная работа 4

GremlinDrive: проектирование API и MCP.

[Отчёт PDF](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/lab4-report.pdf) · [Сайт](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/) · [OpenAPI](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/api.html)

[[Lab4-Requirements]] · [[Lab4-Database]] · [[Lab4-API]] · [[Lab4-MCP]] · [[Lab4-Infrastructure]]
