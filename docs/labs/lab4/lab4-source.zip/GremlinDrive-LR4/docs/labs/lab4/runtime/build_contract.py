"""Generate the designed API contract, trace matrix and importable collections."""
import copy
import json
from pathlib import Path

import api
import store

ROOT = Path(__file__).resolve().parent.parent
REF = lambda name: {"$ref": f"#/components/schemas/{name}"}
UUID = {"type": "string", "format": "uuid"}
TEXT = {"type": "string", "minLength": 1, "maxLength": 255}


def obj(properties, required=None):
    return {"type": "object", "properties": properties, "required": required or list(properties), "additionalProperties": False}


def generate():
    spec = copy.deepcopy(api.app.openapi())
    spec["info"] = {"title": "GremlinDrive API", "version": "1.0.0",
        "description": "Контракт ЛР4 на основе SRS ЛР3. x-implementation отличает stateful-mock от contract-mock. "
                       "Prism симулирует все операции. SQLite mock реализует сценарии файлов, ссылок и квот. "
                       "Промышленная реализация NestJS, SMTP, S3, OAuth, LDAP и мобильная синхронизация в ЛР4 не заявляются."}
    spec["servers"] = [{"url": "http://127.0.0.1:4010", "description": "Prism contract mock"},
                       {"url": "http://127.0.0.1:8044", "description": "Stateful SQLite mock (subset)"}]
    schemas = spec["components"]["schemas"]
    examples = {
        "User": {"id": store.OWNER, "name": "Артём", "role": "user"},
        "Folder": {"id": store.FOLDER, "owner_id": store.OWNER, "parent_id": None, "name": "Учёба"},
        "File": {"id": store.FILE, "owner_id": store.OWNER, "folder_id": store.FOLDER,
                 "name": "Лабораторная.txt", "size_bytes": 64, "status": "active", "version": 1},
        "Quota": {"user_id": store.OWNER, "used_bytes": 64, "total_bytes": 16106127360},
        "ShareLink": {"id": "30000000-0000-4000-8000-000000000001", "file_id": store.FILE,
                      "token": "demo-public-link-token", "url": "/public/shares/demo-public-link-token",
                      "expires_at": 1793404800.0, "access_level": "download"},
        "ShareSummary": {"id": "30000000-0000-4000-8000-000000000001", "file_id": store.FILE,
                         "access_level":"download", "expires_at":1793404800.0, "revoked":0,"downloads":0},
        "AccessRequest": {"id": "40000000-0000-4000-8000-000000000001", "user_id": store.OWNER,
                          "reason": "Нужно место для материалов", "requested_bytes": 21474836480,
                          "status": "pending", "decided_by": None, "comment": None},
        "Version": {"id": store.FILE, "file_id": store.FILE, "version_no": 1, "name": "Лабораторная.txt", "size_bytes": 64},
        "Result": {"status": "accepted"},
        "Notification": {"id": store.FILE, "type": "file_uploaded", "text": "Файл загружен", "is_read": False},
        "Comment": {"id": store.FILE, "file_id": store.FILE, "author_id": store.OWNER, "text": "Готово"},
        "AuditRecord": {"id": 1, "user_id": store.OWNER, "action": "ShareLinkCreated", "entity_id": store.FILE, "created_at": 1792785600.0},
        "Upload": {"id": store.FILE, "received_bytes": 0, "expected_bytes": 64, "status": "pending"},
        "Session": {"access_token": "lab-owner-token", "token_type": "Bearer", "expires_in": 1800},
    }
    def schema_of(value):
        if value is None:
            return {"type": ["string", "null"]}
        if isinstance(value, bool):
            return {"type": "boolean"}
        if isinstance(value, int):
            return {"type": "integer", "minimum": 0}
        if isinstance(value, float):
            return {"type": "number"}
        if isinstance(value, dict):
            return obj({k: schema_of(v) for k, v in value.items()})
        return {"type": "string"}
    for name, example in examples.items():
        schemas[name] = schema_of(example)
    schemas["Error"] = obj({"detail": {"type": "string"}})
    body_examples = {
        "FolderCreate": {"name": "Отчёты", "parent_id": store.FOLDER},
        "FileRename": {"name": "Отчёт.txt"},
        "ShareCreate": {"file_id": store.FILE, "password": "laboratory123", "expires_in_days": 7, "access_level": "download"},
        "ShareAccess": {"password": "laboratory123"},
        "RequestCreate": {"reason": "Нужно место для учебных материалов", "requested_bytes": 21474836480},
        "RequestDecision": {"status": "approved", "comment": "Одобрено", "total_bytes": 21474836480},
        "QuotaUpdate": {"total_bytes": 21474836480},
    }
    # path, method, operation id, body schema, example, result schema, UC, FR, US
    designed = [
      ("/auth/registrations", "post", "register", obj({"name": TEXT, "email": {"type":"string","format":"email"}, "password":{"type":"string","minLength":10,"maxLength":128}}), {"name":"Артём","email":"student@example.test","password":"laboratory123"}, "Result", "UC-01", "FR-01", "US-01"),
      ("/auth/email-confirmations", "post", "confirmEmail", obj({"token":TEXT}), {"token":"demo-confirmation"}, "Result", "UC-01", "FR-01", "US-01"),
      ("/auth/sessions", "post", "login", obj({"email":{"type":"string","format":"email"},"password":{"type":"string","minLength":10,"maxLength":128}}), {"email":"student@example.test","password":"laboratory123"}, "Session", "UC-02", "FR-02,FR-04", "US-02"),
      ("/auth/sessions/current", "delete", "logout", None, None, "Result", "UC-02", "FR-02", "US-02"),
      ("/auth/password-resets", "post", "requestPasswordReset", obj({"email":{"type":"string","format":"email"}}), {"email":"student@example.test"}, "Result", "UC-02", "FR-02", "US-02"),
      ("/auth/totp/enrollments", "post", "enrollTotp", obj({"password":TEXT}), {"password":"laboratory123"}, "Result", "UC-03", "FR-03", "US-12"),
      ("/auth/totp/verifications", "post", "verifyTotp", obj({"code":{"type":"string","pattern":"^[0-9]{6}$"}}), {"code":"123456"}, "Result", "UC-03", "FR-03", "US-12"),
      ("/uploads", "post", "startUpload", obj({"folder_id":UUID,"name":TEXT,"size_bytes":{"type":"integer","minimum":1},"idempotency_key":UUID}), {"folder_id":store.FOLDER,"name":"Материалы.txt","size_bytes":64,"idempotency_key":store.FILE}, "Upload", "UC-05", "FR-06,FR-27", "US-07"),
      ("/uploads/{upload_id}", "get", "getUpload", None, None, "Upload", "UC-05", "FR-06", "US-07"),
      ("/uploads/{upload_id}/parts/{part_no}", "put", "uploadPart", {"type":"string","format":"binary"}, None, "Upload", "UC-05", "FR-06", "US-07"),
      ("/uploads/{upload_id}/completions", "post", "completeUpload", obj({"checksum":{"type":"string","pattern":"^[a-f0-9]{64}$"}}), {"checksum":"a"*64}, "File", "UC-05", "FR-06,FR-07", "US-07"),
      ("/uploads/{upload_id}", "delete", "cancelUpload", None, None, "Result", "UC-05", "FR-06", "US-07"),
      ("/files/{file_id}/content", "get", "downloadFile", None, None, "File", "UC-06", "FR-08,FR-26", "US-06,US-08"),
      ("/files/{file_id}/previews", "get", "previewFile", None, None, "File", "UC-06", "FR-08", "US-06"),
      ("/files/{file_id}/version-restorations", "post", "restoreVersion", obj({"version_id":UUID}), {"version_id":store.FILE}, "Version", "UC-08", "FR-11", "US-06"),
      ("/folders/{folder_id}/invitations", "post", "inviteMember", obj({"email":{"type":"string","format":"email"},"level":{"enum":["view","edit"],"type":"string"}}), {"email":"team@example.test","level":"view"}, "Result", "UC-11", "FR-15", "US-05"),
      ("/invitations/{invitation_id}/acceptances", "post", "acceptInvitation", obj({"token":TEXT}), {"token":"demo-invitation"}, "Result", "UC-11", "FR-15", "US-05"),
      ("/folders/{folder_id}/members", "get", "listMembers", None, None, "User", "UC-12", "FR-16", "US-05"),
      ("/folders/{folder_id}/members/{user_id}", "put", "setMemberRole", obj({"role":{"type":"string","enum":["view","edit"]}}), {"role":"edit"}, "Result", "UC-12", "FR-16", "US-05"),
      ("/folders/{folder_id}/members/{user_id}", "delete", "removeMember", None, None, "Result", "UC-12", "FR-16", "US-05"),
      ("/files/{file_id}/comments", "get", "listComments", None, None, "Comment", "UC-13", "FR-17", "US-13"),
      ("/files/{file_id}/comments", "post", "addComment", obj({"text":{"type":"string","minLength":1,"maxLength":5000}}), {"text":"Готово к проверке"}, "Comment", "UC-13", "FR-17", "US-13"),
      ("/notifications", "get", "listNotifications", None, None, "Notification", "UC-13", "FR-25", "US-13"),
      ("/notifications/{notification_id}", "patch", "readNotification", obj({"is_read":{"type":"boolean"}}), {"is_read":True}, "Notification", "UC-13", "FR-25", "US-13"),
      ("/devices", "post", "registerDevice", obj({"platform":{"type":"string","enum":["android","ios"]},"push_token":TEXT}), {"platform":"android","push_token":"demo-push-token"}, "Result", "UC-17", "FR-25,FR-27", "US-07"),
      ("/sync/changes", "get", "syncChanges", None, None, "File", "UC-17", "FR-26", "US-08"),
      ("/admin/users", "get", "listUsers", None, None, "User", "UC-15", "FR-20", "US-09"),
      ("/admin/users/{user_id}", "patch", "setUserStatus", obj({"status":{"type":"string","enum":["active","blocked"]}}), {"status":"blocked"}, "Result", "UC-15", "FR-20", "US-09"),
      ("/admin/users/{user_id}/roles", "put", "setUserRoles", obj({"roles":{"type":"array","items":{"type":"string","enum":["user","admin"]},"minItems":1,"uniqueItems":True}}), {"roles":["user"]}, "Result", "UC-15", "FR-21", "US-09"),
      ("/admin/ldap-synchronizations", "post", "syncDirectory", obj({"dry_run":{"type":"boolean"}}), {"dry_run":True}, "Result", "UC-18", "FR-22", "US-09"),
      ("/admin/reports", "post", "createReport", obj({"format":{"type":"string","enum":["csv","pdf"]},"type":{"type":"string","enum":["users","audit","usage"]}}), {"format":"csv","type":"users"}, "Result", "UC-16", "FR-23,FR-24,FR-29", "US-09,US-14"),
    ]
    traced = {
      "health": ("UC-19","FR-30","US-09","Result"),
      "getMe": ("UC-02","FR-02,FR-30","US-02","User"),
      "getQuota": ("UC-14","FR-18","US-15","Quota"),
      "listFiles": ("UC-06","FR-09","US-07","File"),
      "getFile": ("UC-06","FR-08","US-06","File"),
      "renameFile": ("UC-04","FR-05","US-07","File"),
      "trashFile": ("UC-07","FR-10","US-11","File"),
      "restoreFile": ("UC-07","FR-10","US-11","File"),
      "listVersions": ("UC-08","FR-11","US-06","Version"),
      "listFolders": ("UC-04","FR-05","US-07","Folder"),
      "createFolder": ("UC-04","FR-05","US-07","Folder"),
      "createShare": ("UC-09","FR-12","US-03","ShareLink"),
      "listShares": ("UC-09","FR-14","US-16","ShareSummary"),
      "revokeShare": ("UC-09","FR-14","US-16","Result"),
      "unlockShare": ("UC-10","FR-13","US-04","Result"),
      "downloadShare": ("UC-10","FR-13","US-04","File"),
      "createAccessRequest": ("UC-14","FR-18","US-15","AccessRequest"),
      "listAccessRequests": ("UC-14","FR-19","US-10","AccessRequest"),
      "decideAccessRequest": ("UC-14","FR-19","US-10","AccessRequest"),
      "setQuota": ("UC-15","FR-21","US-09","Quota"),
      "listAuditRecords": ("UC-16","FR-23","US-14","AuditRecord"),
    }
    for path, method, oid, body, example, result, uc, fr, us in designed:
        path = "/api/v1" + path
        params = []
        for segment in path.split("/"):
            if segment.startswith("{"):
                name = segment[1:-1]
                params.append({"name":name,"in":"path","required":True,
                               "schema":{"type":"integer","minimum":1} if name=="part_no" else UUID})
        op = {"operationId":oid,"summary":oid,"tags":["Designed extensions"],
              "parameters":params,"responses":{"201" if method=="post" else "200":{"description":"Успешный ответ"}},
              "security":[{"HTTPBearer":[]}],"x-implementation":"contract-mock"}
        if oid in {"register","confirmEmail","login","requestPasswordReset"}:
            op["security"] = []
        if body:
            media = "application/octet-stream" if oid=="uploadPart" else "application/json"
            entry = {"schema":body}
            if example is not None:
                entry["example"] = example
            op["requestBody"] = {"required":True,"content":{media:entry}}
        spec["paths"].setdefault(path,{})[method]=op
        traced[oid]=(uc,fr,us,result)
    rows=[]
    postman=[]
    seq=0
    for path, item in spec["paths"].items():
        for method, op in item.items():
            if method not in {"get","post","put","patch","delete"}:
                continue
            seq+=1
            oid=op["operationId"]
            uc,fr,us,result=traced[oid]
            op.update({"x-use-case":uc,"x-requirements":fr.split(","),"x-user-stories":us.split(",")})
            op.setdefault("x-implementation","stateful-mock")
            op["description"] = f"{uc}; {us}; {fr}. {op['x-implementation']}. Все проверки прав выполняет сервер."
            if "requestBody" in op:
                content=op["requestBody"]["content"].get("application/json")
                if content and "$ref" in content["schema"]:
                    body_name=content["schema"]["$ref"].split("/")[-1]
                    content["example"]=body_examples[body_name]
            success=next(k for k in op["responses"] if k.startswith("2"))
            example=examples[result]
            schema=REF(result)
            if oid.startswith("list") or oid=="syncChanges":
                schema=obj({"items":{"type":"array","items":REF(result)}})
                example={"items":[example]}
                if oid=="listFiles":
                    schema["properties"]["total"]={"type":"integer","minimum":0}
                    schema["required"].append("total")
                    example["total"]=1
            if oid=="unlockShare":
                schema=obj({"access_token":{"type":"string"},"file":REF("File"),"access_level":{"type":"string","enum":["view","download"]}})
                example={"access_token":"demo-guest-grant","file":examples["File"],"access_level":"download"}
            if oid=="revokeShare":
                schema=obj({"id":UUID,"revoked":{"type":"boolean"}})
                example={"id":examples["ShareLink"]["id"],"revoked":True}
            if oid=="health":
                schema=obj({"status":{"type":"string"},"mode":{"type":"string"}})
                example={"status":"ok","mode":"lab-mock"}
            op["responses"][success]={"description":"Операция выполнена", "content":{"application/json":{"schema":schema,"example":example}}}
            if oid in {"downloadShare","downloadFile"}:
                op["responses"][success]["content"]={"text/plain":{"schema":{"type":"string"},"example":"GremlinDrive laboratory mock file\n"}}
            for code, description in [("401","Нет сессии или неверный пароль"),("403","Нет права выполнить операцию"),
                                      ("404","Ресурс не найден"),("409","Конфликт состояния"),("422","Неверные параметры")]:
                op["responses"][code]={"description":description,"content":{"application/json":{"schema":REF("Error"),"example":{"detail":description}}}}
            if oid=="unlockShare":
                op["responses"]["429"]={"description":"5 неверных паролей: блокировка 15 минут","content":{"application/json":{"schema":REF("Error"),"example":{"detail":"Повторите через 15 минут"}}}}
            if oid in {"startUpload","uploadPart","completeUpload"}:
                op["responses"]["413"]={"description":"Размер превышает разрешённый"}
                op["responses"]["507"]={"description":"Недостаточно квоты"}
            rows.append({"method":method.upper(),"path":path,"operation":oid,"uc":uc,"fr":fr,"us":us,"implementation":op["x-implementation"]})
            url=path
            import re
            for name in re.findall(r"{([^}]+)}",url):
                value={"file_id":store.FILE,"folder_id":store.FOLDER,"user_id":store.OWNER,"part_no":"1","token":"demo-public-link-token"}.get(name,store.FILE)
                url=url.replace("{"+name+"}",value)
            content=op.get("requestBody",{}).get("content",{}).get("application/json",{})
            body=content.get("example")
            req={"method":method.upper(),"header":[{"key":"Authorization","value":"Bearer {{token}}"}],"url":"{{baseUrl}}"+url}
            if body is not None:
                req["body"]={"mode":"raw","raw":json.dumps(body,ensure_ascii=False),"options":{"raw":{"language":"json"}}}
            postman.append({"name":oid,"request":req})
            bruno=f"meta {{\n  name: {oid}\n  type: http\n  seq: {seq}\n}}\n\n{method} {{\n  url: {{{{baseUrl}}}}{url}\n  body: {'json' if body is not None else 'none'}\n  auth: bearer\n}}\n\nauth:bearer {{\n  token: {{{{token}}}}\n}}\n"
            if body is not None:
                bruno+='\nbody:json {\n'+'\n'.join('  '+line for line in json.dumps(body,ensure_ascii=False,indent=2).splitlines())+'\n}\n'
            if oid=='uploadPart':
                bruno=bruno.replace('body: none','body: text')
                bruno+='\nheaders {\n  Content-Type: application/octet-stream\n}\n\nbody:text {\n  lab data\n}\n'
            bruno+='\ntests {\n  test("Success response", function () { expect(res.status).to.be.within(200, 299); });\n}\n'
            (ROOT/"bruno"/f"{seq:02}-{oid}.bru").write_text(bruno)
    (ROOT/"openapi.json").write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
    (ROOT/"traceability.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    collection={"info":{"name":"GremlinDrive ЛР4","schema":"https://schema.getpostman.com/json/collection/v2.1.0/collection.json"},"variable":[{"key":"baseUrl","value":"http://127.0.0.1:4010"},{"key":"token","value":"lab-owner-token"}],"item":postman}
    (ROOT/"postman_collection.json").write_text(json.dumps(collection,ensure_ascii=False,indent=2)+'\n')
    (ROOT/"bruno"/"bruno.json").write_text(json.dumps({"version":"1","name":"GremlinDrive ЛР4","type":"collection"},indent=2)+'\n')
    env=ROOT/"bruno"/"environments"
    env.mkdir(exist_ok=True)
    (env/"contract.bru").write_text("vars {\n  baseUrl: http://127.0.0.1:4010\n  token: lab-owner-token\n}\n")
    (env/"stateful.bru").write_text("vars {\n  baseUrl: http://127.0.0.1:8044\n  token: lab-owner-token\n}\n")
    print(f"Generated {len(rows)} operations")


if __name__=="__main__":
    generate()
