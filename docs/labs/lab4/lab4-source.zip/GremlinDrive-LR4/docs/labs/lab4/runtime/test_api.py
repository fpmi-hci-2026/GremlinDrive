import pytest
from fastapi.testclient import TestClient

import api
import store


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("GREMLIN_DB", str(tmp_path / "test.db"))
    with TestClient(api.app) as c:
        yield c


def headers(role="owner"):
    return {"Authorization": f"Bearer lab-{role}-token"}


def share(client, **extra):
    return client.post("/api/v1/share-links", headers=headers(), json={
        "file_id": store.FILE, "password": "laboratory123", **extra})


def test_auth_and_cross_user_visibility(client):
    assert client.get("/api/v1/files").status_code == 401
    assert client.get("/api/v1/files", headers=headers("outsider")).json()["total"] == 0
    assert client.get(f"/api/v1/files/{store.FILE}", headers=headers("outsider")).status_code == 403
    assert client.get(f"/api/v1/files/{store.FILE}", headers=headers("reader")).status_code == 200


def test_reader_cannot_mutate_or_publish(client):
    assert client.delete(f"/api/v1/files/{store.FILE}", headers=headers("reader")).status_code == 403
    assert client.post("/api/v1/share-links", headers=headers("reader"), json={
        "file_id": store.FILE, "password": "laboratory123"}).status_code == 403
    assert client.post("/api/v1/folders", headers=headers("reader"), json={
        "name": "Вложенная", "parent_id": store.FOLDER}).status_code == 403


def test_folder_create_duplicate_and_validation(client):
    body = {"name": "Отчёты", "parent_id": store.FOLDER}
    assert client.post("/api/v1/folders", headers=headers(), json=body).status_code == 201
    assert client.post("/api/v1/folders", headers=headers(), json=body).status_code == 409
    assert client.post("/api/v1/folders", headers=headers(), json={"name": "../секрет"}).status_code == 422


@pytest.mark.parametrize("body", [{"password": "short"}, {"expires_in_days": 31},
                                    {"file_id": "invalid"}, {"access_level": "edit"},
                                    {"user_id": store.ADMIN}])
def test_share_schema_rejects_invalid_input(client, body):
    assert share(client, **body).status_code == 422


def test_protected_share_flow_and_revocation(client):
    response = share(client)
    assert response.status_code == 201
    link = response.json()
    base = f'/api/v1/public/shares/{link["token"]}'
    assert client.get(base + "/content").status_code == 401
    assert client.post(base + "/access", json={"password": "wrong"}).status_code == 401
    access = client.post(base + "/access", json={"password": "laboratory123"}).json()
    auth = {"X-Share-Access": access["access_token"]}
    assert client.get(base + "/content", headers=auth).status_code == 200
    assert client.get("/api/v1/share-links", headers=headers()).json()["items"][0]["downloads"] == 1
    assert client.delete(f'/api/v1/share-links/{link["id"]}', headers=headers()).status_code == 200
    assert client.get(base + "/content", headers=auth).status_code == 404


def test_guest_lockout(client):
    token = share(client).json()["token"]
    endpoint = f"/api/v1/public/shares/{token}/access"
    for _ in range(5):
        assert client.post(endpoint, json={"password": "wrong"}).status_code == 401
    assert client.post(endpoint, json={"password": "laboratory123"}).status_code == 429


def test_expiry_no_metadata_leak(client):
    link = share(client).json()
    with store.connection() as c:
        c.execute("UPDATE share_links SET expires_at=0")
    response = client.post(f'/api/v1/public/shares/{link["token"]}/access', json={"password": "laboratory123"})
    assert response.status_code == 404
    assert "Лабораторная" not in response.text


def test_view_only_share_cannot_download(client):
    link = share(client, access_level="view").json()
    endpoint = f'/api/v1/public/shares/{link["token"]}'
    grant = client.post(endpoint + "/access", json={"password": "laboratory123"}).json()["access_token"]
    assert client.get(endpoint + "/content", headers={"X-Share-Access": grant}).status_code == 403


def test_trash_revoke_restore_does_not_republish(client):
    link = share(client).json()
    assert client.delete(f"/api/v1/files/{store.FILE}", headers=headers()).status_code == 200
    assert share(client).status_code == 409
    assert client.post(f"/api/v1/files/{store.FILE}/restorations", headers=headers()).status_code == 201
    assert client.post(f'/api/v1/public/shares/{link["token"]}/access', json={"password": "laboratory123"}).status_code == 404


def test_quarantine_blocks_publication(client):
    with store.connection() as c:
        c.execute("UPDATE files SET status='quarantine'")
    assert share(client).status_code == 409


def test_quota_decision_is_atomic_and_single_use(client):
    req = client.post("/api/v1/access-requests", headers=headers(), json={
        "reason": "Нужно место для учебных материалов", "requested_bytes": 20 * 1024**3}).json()
    endpoint = f'/api/v1/admin/access-requests/{req["id"]}/decisions'
    body = {"status": "approved", "comment": "Одобрено", "total_bytes": 20 * 1024**3}
    assert client.post(endpoint, headers=headers(), json=body).status_code == 403
    assert client.post(endpoint, headers=headers("admin"), json=body).status_code == 201
    assert client.get("/api/v1/me/quota", headers=headers()).json()["total_bytes"] == 20 * 1024**3
    assert client.post(endpoint, headers=headers("admin"), json=body).status_code == 409


def test_quota_cannot_drop_below_usage(client):
    endpoint = f"/api/v1/admin/users/{store.OWNER}/quota"
    assert client.put(endpoint, headers=headers("admin"), json={"total_bytes": 1}).status_code == 409


def test_audit_does_not_contain_password_or_tokens(client):
    link = share(client).json()
    audit = client.get("/api/v1/admin/audit-records", headers=headers("admin"))
    assert audit.status_code == 200
    assert "ShareLinkCreated" in audit.text
    assert "laboratory123" not in audit.text and link["token"] not in audit.text
    assert client.get("/api/v1/admin/audit-records", headers=headers()).status_code == 403


def test_pagination_and_invalid_id(client):
    assert client.get("/api/v1/files?limit=0", headers=headers()).status_code == 422
    assert client.get("/api/v1/files/no-id", headers=headers()).status_code == 422
    assert client.get("/api/v1/files?q=нет-совпадений", headers=headers()).json()["total"] == 0
