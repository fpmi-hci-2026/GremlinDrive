"""Exercise every designed operation against Prism, validating response schemas."""
import json
import os
import re
import warnings
from pathlib import Path

import httpx
from jsonschema import Draft202012Validator, RefResolver
from openapi_spec_validator import validate

ROOT=Path(__file__).resolve().parent.parent


def check():
    spec=json.loads((ROOT/'openapi.json').read_text())
    validate(spec)
    results=[]
    warnings.filterwarnings('ignore', category=DeprecationWarning)
    resolver=RefResolver.from_schema(spec)
    with httpx.Client(base_url=os.environ.get('PRISM_URL','http://127.0.0.1:4010'),timeout=20) as client:
        for path,item in spec['paths'].items():
            for method,op in item.items():
                if method not in {'get','post','put','patch','delete'}:
                    continue
                url=path
                for name in re.findall(r'{([^}]+)}',url):
                    val='1' if name=='part_no' else ('demo-public-link-token' if name=='token' else '20000000-0000-4000-8000-000000000001')
                    url=url.replace('{'+name+'}',val)
                content=op.get('requestBody',{}).get('content',{})
                kwargs={'headers':{'Authorization':'Bearer lab-owner-token'}}
                if 'application/json' in content:
                    kwargs['json']=content['application/json'].get('example',{})
                elif 'application/octet-stream' in content:
                    kwargs['content']=b'lab data'
                    kwargs['headers']['Content-Type']='application/octet-stream'
                response=client.request(method,url,**kwargs)
                status=str(response.status_code)
                assert response.is_success, (op['operationId'],status,response.text)
                media=op['responses'][status].get('content',{})
                if 'application/json' in media:
                    validator=Draft202012Validator(media['application/json']['schema'],resolver=resolver)
                    validator.validate(response.json())
                results.append({'operation':op['operationId'],'method':method.upper(),'path':path,'status':response.status_code,'response_schema':'PASS'})
        invalid=client.post('/api/v1/share-links',headers={'Authorization':'Bearer lab-owner-token'},json={'file_id':'bad','password':'x'})
        assert invalid.status_code==422, (invalid.status_code,invalid.text)
        forbidden=client.post('/api/v1/share-links',headers={'Authorization':'Bearer lab-owner-token','Prefer':'code=403'},json={
            'file_id':'20000000-0000-4000-8000-000000000001','password':'laboratory123'})
        assert forbidden.status_code==403
    result={'openapi_validation':'PASS','operations':results,'negative_validation':invalid.status_code,
            'forced_forbidden_example':forbidden.status_code,
            'scope':'Prism examples and schema validation; business invariants tested separately against SQLite mock'}
    (ROOT/'evidence/contract-tests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(f'{len(results)} operations: success responses match schemas; invalid input 422; forbidden example 403')


if __name__=='__main__':
    check()
