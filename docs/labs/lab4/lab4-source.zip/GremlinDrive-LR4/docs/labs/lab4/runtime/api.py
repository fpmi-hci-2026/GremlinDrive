"""Stateful lab mock. Production services are specified separately in openapi.json."""
from contextlib import asynccontextmanager
from typing import Annotated, Literal
from uuid import UUID, uuid4

from fastapi import Depends, FastAPI, Header, Query, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field

import store


@asynccontextmanager
async def lifespan(app):
    store.initialize()
    yield


app = FastAPI(title="GremlinDrive stateful mock", version="1.0.0", lifespan=lifespan,
              description="Учебная SQLite-модель. Только демонстрационные данные и токены.")
bearer = HTTPBearer(auto_error=False)


@app.exception_handler(store.DomainError)
async def domain_error(request: Request, exc: store.DomainError):
    return JSONResponse(status_code=exc.status, content={"detail": exc.detail})


@app.exception_handler(RequestValidationError)
async def validation_error(request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"detail": "Проверьте параметры запроса"})


def actor(auth: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]):
    return store.principal(auth.credentials if auth else "")


User = Annotated[str, Depends(actor)]


class StrictBody(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FolderCreate(StrictBody):
    name: str = Field(min_length=1, max_length=255, pattern=r"^[^/\\]+$")
    parent_id: UUID | None = None


class FileRename(StrictBody):
    name: str = Field(min_length=1, max_length=255, pattern=r"^[^/\\]+$")


class ShareCreate(StrictBody):
    file_id: UUID
    password: str | None = Field(default=None, min_length=8, max_length=128)
    expires_in_days: int = Field(default=7, ge=1, le=30)
    access_level: Literal["view", "download"] = "download"


class ShareAccess(StrictBody):
    password: str | None = Field(default=None, max_length=128)


class QuotaUpdate(StrictBody):
    total_bytes: int = Field(ge=0, le=1024**5)


class RequestCreate(StrictBody):
    reason: str = Field(min_length=5, max_length=1000)
    requested_bytes: int = Field(gt=0, le=1024**5)


class RequestDecision(StrictBody):
    status: Literal["approved", "rejected"]
    comment: str = Field(min_length=1, max_length=1000)
    total_bytes: int | None = Field(default=None, ge=0, le=1024**5)


ERRORS = {code: {"description": text} for code, text in {
    401: "Нет действующей сессии или неверный пароль", 403: "Недостаточно прав",
    404: "Объект не найден либо ссылка недействительна", 409: "Конфликт состояния",
    422: "Ошибка валидации", 429: "Превышен лимит попыток"}.items()}


@app.get("/health", tags=["Infrastructure"], operation_id="health")
def health():
    return {"status": "ok", "mode": "lab-mock"}


@app.get("/api/v1/me", tags=["Identity"], responses=ERRORS, operation_id="getMe")
def get_me(user: User):
    with store.connection() as c:
        return dict(c.execute("SELECT * FROM users WHERE id=?", (user,)).fetchone())


@app.get("/api/v1/me/quota", tags=["Administration"], responses=ERRORS, operation_id="getQuota")
def get_quota(user: User):
    return store.quota(user)


@app.get("/api/v1/files", tags=["Files"], responses=ERRORS, operation_id="listFiles")
def files(user: User, q: str = Query(default="", max_length=255),
          status: Literal["active", "trashed", "quarantine"] = "active",
          limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0)):
    return store.list_files(user, q, status, limit, offset)


@app.get("/api/v1/files/{file_id}", tags=["Files"], responses=ERRORS, operation_id="getFile")
def get_file(file_id: UUID, user: User):
    return store.get_file(user, str(file_id))


@app.patch("/api/v1/files/{file_id}", tags=["Files"], responses=ERRORS, operation_id="renameFile")
def rename_file(file_id: UUID, body: FileRename, user: User):
    return store.change_file(user, str(file_id), body.name)


@app.delete("/api/v1/files/{file_id}", tags=["Files"], responses=ERRORS, operation_id="trashFile")
def trash_file(file_id: UUID, user: User):
    return store.set_file_status(user, str(file_id), "trashed")


@app.post("/api/v1/files/{file_id}/restorations", tags=["Files"], status_code=201,
          responses=ERRORS, operation_id="restoreFile")
def restore_file(file_id: UUID, user: User):
    return store.set_file_status(user, str(file_id), "active")


@app.get("/api/v1/files/{file_id}/versions", tags=["Files"], responses=ERRORS, operation_id="listVersions")
def versions(file_id: UUID, user: User):
    with store.connection() as c:
        store.file_access(c, user, str(file_id))
        return {"items": [dict(r) for r in c.execute(
            "SELECT * FROM versions WHERE file_id=? ORDER BY version_no DESC", (str(file_id),))]}


@app.get("/api/v1/folders", tags=["Folders"], responses=ERRORS, operation_id="listFolders")
def folders(user: User):
    with store.connection() as c:
        items = []
        for row in c.execute("SELECT * FROM folders ORDER BY name").fetchall():
            try:
                store.folder_access(c, user, row["id"])
                items.append(dict(row))
            except store.DomainError:
                pass
        return {"items": items}


@app.post("/api/v1/folders", tags=["Folders"], status_code=201, responses=ERRORS, operation_id="createFolder")
def create_folder(body: FolderCreate, user: User):
    return store.create_folder(user, body.name, str(body.parent_id) if body.parent_id else None)


@app.post("/api/v1/share-links", tags=["Sharing"], status_code=201, responses=ERRORS, operation_id="createShare")
def create_share(body: ShareCreate, user: User):
    return store.create_share(user, str(body.file_id), body.password, body.expires_in_days, body.access_level)


@app.get("/api/v1/share-links", tags=["Sharing"], responses=ERRORS, operation_id="listShares")
def list_shares(user: User):
    with store.connection() as c:
        rows = c.execute("SELECT id,file_id,access_level,expires_at,revoked,downloads FROM share_links WHERE created_by=?",
                         (user,)).fetchall()
        return {"items": [dict(r) for r in rows]}


@app.delete("/api/v1/share-links/{share_id}", tags=["Sharing"], responses=ERRORS, operation_id="revokeShare")
def revoke_share(share_id: UUID, user: User):
    return store.revoke_share(user, str(share_id))


@app.post("/api/v1/public/shares/{token}/access", tags=["Public"], responses=ERRORS, operation_id="unlockShare")
def unlock(token: str, body: ShareAccess):
    return store.unlock_share(token, body.password)


@app.get("/api/v1/public/shares/{token}/content", tags=["Public"], responses=ERRORS,
         response_class=Response, operation_id="downloadShare")
def download(token: str, x_share_access: Annotated[str | None, Header()] = None):
    store.download_share(token, x_share_access)
    return Response(b"GremlinDrive laboratory mock file\n", media_type="text/plain",
                    headers={"Content-Disposition": 'attachment; filename="lab.txt"'})


@app.post("/api/v1/access-requests", tags=["Administration"], status_code=201,
          responses=ERRORS, operation_id="createAccessRequest")
def request_quota(body: RequestCreate, user: User):
    rid = str(uuid4())
    with store.connection() as c:
        c.execute("INSERT INTO access_requests(id,user_id,reason,requested_bytes) VALUES(?,?,?,?)",
                  (rid, user, body.reason, body.requested_bytes))
        store.audit(c, user, "AccessRequestCreated", rid)
        return dict(c.execute("SELECT * FROM access_requests WHERE id=?", (rid,)).fetchone())


@app.get("/api/v1/admin/access-requests", tags=["Administration"], responses=ERRORS, operation_id="listAccessRequests")
def requests(user: User):
    store.require_admin(user)
    with store.connection() as c:
        return {"items": [dict(r) for r in c.execute("SELECT * FROM access_requests ORDER BY id")]}


@app.post("/api/v1/admin/access-requests/{request_id}/decisions", tags=["Administration"],
          status_code=201, responses=ERRORS, operation_id="decideAccessRequest")
def decide(request_id: UUID, body: RequestDecision, user: User):
    store.require_admin(user)
    with store.connection() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT * FROM access_requests WHERE id=?", (str(request_id),)).fetchone()
        if not row:
            raise store.DomainError(404, "Запрос не найден")
        if row["status"] != "pending":
            raise store.DomainError(409, "Решение уже принято")
        if body.status == "approved":
            if body.total_bytes is None:
                raise store.DomainError(422, "Укажите новую квоту")
            if body.total_bytes < store.quota(row["user_id"])["used_bytes"]:
                raise store.DomainError(409, "Квота меньше занятого объёма")
            c.execute("UPDATE quotas SET total_bytes=? WHERE user_id=?", (body.total_bytes, row["user_id"]))
        c.execute("UPDATE access_requests SET status=?,decided_by=?,comment=? WHERE id=?",
                  (body.status, user, body.comment, str(request_id)))
        store.audit(c, user, "AccessRequestDecided", str(request_id))
        return dict(c.execute("SELECT * FROM access_requests WHERE id=?", (str(request_id),)).fetchone())


@app.put("/api/v1/admin/users/{user_id}/quota", tags=["Administration"], responses=ERRORS, operation_id="setQuota")
def set_quota(user_id: UUID, body: QuotaUpdate, user: User):
    store.require_admin(user)
    with store.connection() as c:
        c.execute("BEGIN IMMEDIATE")
        current = store.quota(str(user_id))
        if body.total_bytes < current["used_bytes"]:
            raise store.DomainError(409, "Квота меньше занятого объёма")
        c.execute("UPDATE quotas SET total_bytes=? WHERE user_id=?", (body.total_bytes, str(user_id)))
        store.audit(c, user, "QuotaChanged", str(user_id))
    return store.quota(str(user_id))


@app.get("/api/v1/admin/audit-records", tags=["Administration"], responses=ERRORS, operation_id="listAuditRecords")
def audit_records(user: User, limit: int = Query(default=50, ge=1, le=100)):
    store.require_admin(user)
    with store.connection() as c:
        return {"items": [dict(r) for r in c.execute("SELECT * FROM audit_records ORDER BY id DESC LIMIT ?", (limit,))]}
