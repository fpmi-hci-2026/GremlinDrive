"""Export the lab documentation, excluding environments and local data."""
import html
import re
import shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'web'


def inline(s):
    s=html.escape(s.replace('—','-'))
    s=re.sub(r'`([^`]+)`',r'<code>\1</code>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',s)
    s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',s)
    return s


def md(source):
    lines=source.splitlines()
    out=[]
    i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:
            i+=1
            continue
        if line.startswith('```'):
            block=[]
            i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                block.append(lines[i])
                i+=1
            out.append('<pre><code>'+html.escape('\n'.join(block))+'</code></pre>')
            i+=1
            continue
        if line.startswith('!['):
            match=re.match(r'!\[([^\]]*)\]\(([^)]+)\)',line)
            out.append(f'<figure><a href="{match[2]}"><img loading="lazy" src="{match[2]}" alt="{html.escape(match[1])}"></a><figcaption>Открыть схему в полном размере</figcaption></figure>')
            i+=1
            continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+',x) for x in row):
                    rows.append(row)
                i+=1
            out.append('<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+inline(v)+'</th>' for v in rows[0])+'</tr></thead><tbody>')
            for row in rows[1:]:
                out.append('<tr>'+''.join('<td>'+inline(v)+'</td>' for v in row)+'</tr>')
            out.append('</tbody></table></div>')
            continue
        if line.startswith('#'):
            level=min(4,len(line)-len(line.lstrip('#'))+1)
            out.append(f'<h{level}>'+inline(line.lstrip('#').strip())+f'</h{level}>')
            i+=1
            continue
        paragraph=[line]
        i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','![')):
            paragraph.append(lines[i].strip())
            i+=1
        out.append('<p>'+inline(' '.join(paragraph))+'</p>')
    return '\n'.join(out)


def generate():
    OUT.mkdir(exist_ok=True)
    for filename in ['openapi.json','mock-openapi.json','postman_collection.json','traceability.json',
                     'lab4-report.pdf','mcp-client.example.json','requirements.md','api-design.md','mcp.md','infrastructure.md']:
        shutil.copy2(ROOT/filename,OUT/filename)
    for folder in ['diagrams','database','bruno']:
        shutil.copytree(ROOT/folder,OUT/folder,dirs_exist_ok=True)
    (OUT/'evidence').mkdir(exist_ok=True)
    for filename in ['contract-tests.json','bruno-summary.json','mcp-protocol.json','inspector-tools.json','postgresql.txt']:
        shutil.copy2(ROOT/'evidence'/filename,OUT/'evidence'/filename)
    parts=[]
    for anchor,filename in [('requirements','requirements.md'),('database','database/logical-model.md'),
                            ('api','api-design.md'),('mcp','mcp.md'),('infrastructure','infrastructure.md')]:
        parts.append(f'<section id="{anchor}">'+md((ROOT/filename).read_text())+'</section>')
    diagrams=''.join(f'<figure><a href="diagrams/{name}.png"><img loading="lazy" src="diagrams/{name}.png" alt="{label}"></a><figcaption>{label}. <a href="diagrams/{name}.puml">PlantUML</a></figcaption></figure>'
        for name,label in [('logical','Логическая модель'),('physical-identity','Пользователи и управление'),
                           ('physical-storage','Файлы и загрузка'),('physical-sharing','Общий доступ')])
    page='''<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ЛР4 API и MCP · GremlinDrive</title><link rel="stylesheet" href="lab4.css"></head><body>
<header class="site-header"><a href="https://fpmi-hci-2026.github.io/GremlinDrive/" class="brand"><span class="brand-mark">G</span>GremlinDrive</a><nav aria-label="Навигация"><a href="https://fpmi-hci-2026.github.io/GremlinDrive/labs/">Лабораторные</a><a href="api.html">Документация API</a><a href="https://github.com/fpmi-hci-2026/hci-10-project-group-4/tree/main/docs/labs/lab4">Исходники</a></nav></header>
<main><div class="hero"><p class="eyebrow">Лабораторная работа 4 · группа 10а</p><h1>API и интеграция<br>с AI-ассистентом</h1>
<p class="lead">GremlinDrive: от требований и схемы данных к проверяемому API и работающему MCP-серверу.</p>
<div class="actions"><a class="button" href="lab4-report.pdf">Отчёт PDF</a><a class="button secondary" href="api.html">Открыть Swagger UI</a><a class="button secondary" href="lab4-source.zip">Скачать комплект</a></div>
<div class="metrics"><span><strong>52</strong> операции API</span><span><strong>17</strong> таблиц PostgreSQL</span><span><strong>7</strong> MCP-инструментов</span><span><strong>22</strong> теста pytest</span></div></div>
<nav class="toc" aria-label="Разделы"><a href="#requirements">Требования</a><a href="#database">Данные</a><a href="#models">Диаграммы</a><a href="#api">API</a><a href="#verification">Проверки</a><a href="#mcp">MCP</a><a href="#infrastructure">Инфраструктура</a></nav>
<section id="verification"><h2>Проверки</h2><p>В Bruno прошли 52 запроса и 52 теста. Контракт отдельно проверен по схемам ответов. Pytest выполнил 22 теста, покрытие REST mock и доменной логики составляет 87,50%. PostgreSQL прошёл восемь проверок ограничений. MCP проверен по stdio и через официальный Inspector.</p>
<p>Prism симулирует весь контракт. Stateful mock реализует 21 операцию с SQLite. Поле <code>x-implementation</code> в OpenAPI показывает границу между ними.</p>
<p><a href="evidence/contract-tests.json">Протокол API</a> · <a href="evidence/bruno-summary.json">Bruno</a> · <a href="evidence/mcp-protocol.json">MCP и JSON-схемы</a> · <a href="evidence/postgresql.txt">PostgreSQL</a></p></section>
'''+''.join(parts)+f'<section id="models"><h2>Диаграммы данных</h2>{diagrams}</section>'+'''
</main><footer>Александр Сытин · исходные требования ЛР3: Матвей Вержбиба · ФПМИ БГУ · 2026</footer></body></html>'''
    (OUT/'index.html').write_text(page)
    (OUT/'lab4.css').write_text((ROOT.parent/'shared/labs.css').read_text()+"\n"+(ROOT.parent/'shared/report-pages.css').read_text())
    (OUT/'api.html').write_text('''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GremlinDrive OpenAPI</title><link rel="stylesheet" href="swagger/swagger-ui.css"></head><body style="margin:0"><nav style="padding:16px;font:16px sans-serif"><a href="index.html">К материалам ЛР4</a> · <a href="openapi.json">Скачать OpenAPI JSON</a></nav><div id="swagger-ui"></div><script src="swagger/swagger-ui-bundle.js"></script><script>SwaggerUIBundle({url:'openapi.json',dom_id:'#swagger-ui',deepLinking:true,persistAuthorization:false});</script></body></html>''')
    print(OUT)


if __name__=='__main__':
    generate()
