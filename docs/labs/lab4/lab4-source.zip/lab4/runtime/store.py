"""Isolated SQLite fixture shared by the REST mock and MCP MVP.

Demo users and tokens are deliberately public, and must never protect real data.
"""
import hashlib
import hmac
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

OWNER = "00000000-0000-4000-8000-000000000001"
READER = "00000000-0000-4000-8000-000000000002"
ADMIN = "00000000-0000-4000-8000-000000000003"
OUTSIDER = "00000000-0000-4000-8000-000000000004"
FOLDER = "10000000-0000-4000-8000-000000000001"
FILE = "20000000-0000-4000-8000-000000000001"
TOKENS = {"lab-owner-token": OWNER, "lab-reader-token": READER,
          "lab-admin-token": ADMIN, "lab-outsider-token": OUTSIDER}


class DomainError(Exception):
    def __init__(self, status, detail):
        self.status, self.detail = status, detail
        super().__init__(detail)


def db_path():
    return Path(os.environ.get("GREMLIN_DB", Path(__file__).with_name("demo.db")))


@contextmanager
def connection():
    con = sqlite3.connect(db_path(), timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        with con:
            yield con
    finally:
        con.close()


def initialize():
    db_path().parent.mkdir(parents=True, exist_ok=True)
    with connection() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS folders(id TEXT PRIMARY KEY,owner_id TEXT REFERENCES users(id),
          parent_id TEXT REFERENCES folders(id),name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS folder_members(folder_id TEXT REFERENCES folders(id),
          user_id TEXT REFERENCES users(id),role TEXT CHECK(role IN ('view','edit')),
          PRIMARY KEY(folder_id,user_id));
        CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,owner_id TEXT REFERENCES users(id),
          folder_id TEXT REFERENCES folders(id),name TEXT NOT NULL,size_bytes INTEGER NOT NULL,
          status TEXT CHECK(status IN ('active','trashed','quarantine')),version INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS versions(id TEXT PRIMARY KEY,file_id TEXT REFERENCES files(id),
          version_no INTEGER NOT NULL,name TEXT NOT NULL,size_bytes INTEGER NOT NULL,
          UNIQUE(file_id,version_no));
        CREATE TABLE IF NOT EXISTS share_links(id TEXT PRIMARY KEY,file_id TEXT REFERENCES files(id),
          token_hash TEXT UNIQUE NOT NULL,password_hash TEXT,access_level TEXT NOT NULL,
          expires_at REAL,revoked INTEGER NOT NULL DEFAULT 0,downloads INTEGER NOT NULL DEFAULT 0,
          created_by TEXT REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS guest_attempts(token_hash TEXT PRIMARY KEY,failures INTEGER NOT NULL,
          locked_until REAL NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS grants(token_hash TEXT PRIMARY KEY,share_id TEXT REFERENCES share_links(id),
          expires_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS audit_records(id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT,action TEXT NOT NULL,entity_id TEXT NOT NULL,created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS quotas(user_id TEXT PRIMARY KEY REFERENCES users(id),
          total_bytes INTEGER CHECK(total_bytes>=0));
        CREATE TABLE IF NOT EXISTS access_requests(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),
          reason TEXT NOT NULL,requested_bytes INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
          decided_by TEXT REFERENCES users(id),comment TEXT);
        """)
        migrate_share_expiry(c)
        for uid, name, role in [(OWNER, "Артём", "user"), (READER, "Ольга", "user"),
                                (ADMIN, "Администратор", "admin"), (OUTSIDER, "Другой пользователь", "user")]:
            c.execute("INSERT OR IGNORE INTO users VALUES(?,?,?)", (uid, name, role))
            c.execute("INSERT OR IGNORE INTO quotas VALUES(?,?)", (uid, 15 * 1024**3))
        c.execute("INSERT OR IGNORE INTO folders VALUES(?,?,NULL,?)", (FOLDER, OWNER, "Учёба"))
        c.execute("INSERT OR IGNORE INTO folder_members VALUES(?,?,?)", (FOLDER, READER, "view"))
        c.execute("INSERT OR IGNORE INTO files VALUES(?,?,?,?,?,?,1)",
                  (FILE, OWNER, FOLDER, "Лабораторная.txt", 64, "active"))
        c.execute("INSERT OR IGNORE INTO versions VALUES(?,?,1,?,?)", (FILE, FILE, "Лабораторная.txt", 64))


def migrate_share_expiry(c):
    """Retain links and grants when opening the earlier NOT NULL demo schema."""
    if not any(row["name"] == "expires_at" and row["notnull"] for row in c.execute("PRAGMA table_info(share_links)")):
        return
    c.execute("PRAGMA foreign_keys=OFF")
    c.executescript("""
    BEGIN IMMEDIATE;
    CREATE TABLE share_links_new(id TEXT PRIMARY KEY,file_id TEXT REFERENCES files(id),
      token_hash TEXT UNIQUE NOT NULL,password_hash TEXT,access_level TEXT NOT NULL,
      expires_at REAL,revoked INTEGER NOT NULL DEFAULT 0,downloads INTEGER NOT NULL DEFAULT 0,
      created_by TEXT REFERENCES users(id));
    INSERT INTO share_links_new SELECT * FROM share_links;
    DROP TABLE share_links;
    ALTER TABLE share_links_new RENAME TO share_links;
    COMMIT;
    """)
    c.execute("PRAGMA foreign_keys=ON")


def audit(c, user, action, entity):
    c.execute("INSERT INTO audit_records(user_id,action,entity_id,created_at) VALUES(?,?,?,?)",
              (user, action, entity, time.time()))


def principal(token):
    if token not in TOKENS:
        raise DomainError(401, "Требуется демонстрационный Bearer-токен")
    return TOKENS[token]


def require_admin(user):
    if user != ADMIN:
        raise DomainError(403, "Действие доступно администратору")


def folder_access(c, user, folder_id, write=False):
    folder = c.execute("SELECT * FROM folders WHERE id=?", (folder_id,)).fetchone()
    if not folder:
        raise DomainError(404, "Папка не найдена")
    if folder["owner_id"] == user:
        return folder
    membership = c.execute("SELECT role FROM folder_members WHERE folder_id=? AND user_id=?",
                           (folder_id, user)).fetchone()
    if membership and (not write or membership["role"] == "edit"):
        return folder
    if folder["parent_id"]:
        folder_access(c, user, folder["parent_id"], write)
        return folder
    raise DomainError(403, "Нет доступа к папке")


def file_access(c, user, file_id, write=False):
    row = c.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
    if not row:
        raise DomainError(404, "Файл не найден")
    if row["owner_id"] != user:
        if not row["folder_id"]:
            raise DomainError(403, "Нет доступа к файлу")
        folder_access(c, user, row["folder_id"], write)
    return row


def list_files(user, query="", status="active", limit=50, offset=0):
    with connection() as c:
        found = []
        rows = c.execute("SELECT * FROM files WHERE status=? ORDER BY name,id", (status,)).fetchall()
        for row in rows:
            try:
                file_access(c, user, row["id"])
            except DomainError:
                continue
            if query.casefold() in row["name"].casefold():
                found.append(dict(row))
        return {"items": found[offset:offset + limit], "total": len(found)}


def get_file(user, file_id):
    with connection() as c:
        return dict(file_access(c, user, file_id))


def create_folder(user, name, parent_id=None):
    if not name.strip() or "/" in name or "\\" in name:
        raise DomainError(422, "Некорректное имя папки")
    with connection() as c:
        owner = user
        if parent_id:
            parent = folder_access(c, user, parent_id, True)
            owner = parent["owner_id"]
        if c.execute("SELECT 1 FROM folders WHERE owner_id=? AND parent_id IS ? AND name=?",
                     (owner, parent_id, name)).fetchone():
            raise DomainError(409, "Папка с таким именем уже существует")
        fid = str(uuid4())
        c.execute("INSERT INTO folders VALUES(?,?,?,?)", (fid, owner, parent_id, name))
        audit(c, user, "FolderCreated", fid)
        return dict(c.execute("SELECT * FROM folders WHERE id=?", (fid,)).fetchone())


def change_file(user, file_id, name):
    with connection() as c:
        row = file_access(c, user, file_id, True)
        if row["status"] != "active":
            raise DomainError(409, "Изменять можно только активный файл")
        c.execute("UPDATE files SET name=? WHERE id=?", (name, file_id))
        audit(c, user, "FileRenamed", file_id)
        return dict(c.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone())


def set_file_status(user, file_id, status):
    with connection() as c:
        row = file_access(c, user, file_id, True)
        expected = "active" if status == "trashed" else "trashed"
        if row["status"] != expected:
            raise DomainError(409, f"Нужен файл в состоянии {expected}")
        c.execute("UPDATE files SET status=? WHERE id=?", (status, file_id))
        if status == "trashed":
            c.execute("UPDATE share_links SET revoked=1 WHERE file_id=?", (file_id,))
        audit(c, user, "FileTrashed" if status == "trashed" else "FileRestored", file_id)
        return dict(c.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone())


def quota(user):
    with connection() as c:
        total = c.execute("SELECT total_bytes FROM quotas WHERE user_id=?", (user,)).fetchone()
        if not total:
            raise DomainError(404, "Пользователь не найден")
        used = c.execute("SELECT COALESCE(SUM(size_bytes),0) FROM files WHERE owner_id=?", (user,)).fetchone()[0]
        return {"user_id": user, "used_bytes": used, "total_bytes": total[0]}


def hash_token(value):
    return hashlib.sha256(value.encode()).hexdigest()


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    value = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()
    return salt + ":" + value


def create_share(user, file_id, password, expires_in_days=14, access_level="download"):
    if (expires_in_days is not None and not 1 <= expires_in_days <= 30) or access_level not in {"view", "download"}:
        raise DomainError(422, "Некорректные параметры ссылки")
    if password is not None and len(password) < 8:
        raise DomainError(422, "Пароль должен содержать не менее 8 символов")
    with connection() as c:
        file = file_access(c, user, file_id, True)
        if file["status"] != "active":
            raise DomainError(409, "Нельзя публиковать файл из корзины или карантина")
        sid, token = str(uuid4()), secrets.token_urlsafe(32)
        until = time.time() + expires_in_days * 86400 if expires_in_days is not None else None
        c.execute("INSERT INTO share_links(id,file_id,token_hash,password_hash,access_level,expires_at,created_by) VALUES(?,?,?,?,?,?,?)",
                  (sid, file_id, hash_token(token), password_hash(password) if password else None,
                   access_level, until, user))
        audit(c, user, "ShareLinkCreated", sid)
        return {"id": sid, "file_id": file_id, "token": token,
                "url": f"/public/shares/{token}", "expires_at": until, "access_level": access_level}


def revoke_share(user, share_id):
    with connection() as c:
        row = c.execute("SELECT * FROM share_links WHERE id=?", (share_id,)).fetchone()
        if not row:
            raise DomainError(404, "Ссылка не найдена")
        file_access(c, user, row["file_id"], True)
        c.execute("UPDATE share_links SET revoked=1 WHERE id=?", (share_id,))
        audit(c, user, "ShareLinkRevoked", share_id)
        return {"id": share_id, "revoked": True}


def active_share(c, token):
    row = c.execute("SELECT * FROM share_links WHERE token_hash=?", (hash_token(token),)).fetchone()
    if not row or row["revoked"] or (row["expires_at"] is not None and row["expires_at"] <= time.time()):
        raise DomainError(404, "Ссылка недействительна")
    file = c.execute("SELECT * FROM files WHERE id=?", (row["file_id"],)).fetchone()
    if file["status"] != "active":
        raise DomainError(404, "Ссылка недействительна")
    return row, file


def unlock_share(token, password):
    # Failed attempts must commit even though the API returns an error.
    error = None
    with connection() as c:
        row, file = active_share(c, token)
        attempt = c.execute("SELECT * FROM guest_attempts WHERE token_hash=?", (hash_token(token),)).fetchone()
        if attempt and attempt["locked_until"] > time.time():
            raise DomainError(429, "Повторите через 15 минут")
        correct = not row["password_hash"] or (password is not None and hmac.compare_digest(
            password_hash(password, row["password_hash"].split(":")[0]), row["password_hash"]))
        if not correct:
            failures = (attempt["failures"] if attempt and attempt["locked_until"] == 0 else 0) + 1
            c.execute("INSERT OR REPLACE INTO guest_attempts VALUES(?,?,?)",
                      (hash_token(token), failures, time.time() + 900 if failures >= 5 else 0))
            error = DomainError(401, "Неверный пароль")
        else:
            c.execute("DELETE FROM guest_attempts WHERE token_hash=?", (hash_token(token),))
            grant = secrets.token_urlsafe(32)
            c.execute("INSERT INTO grants VALUES(?,?,?)", (hash_token(grant), row["id"], time.time() + 300))
            result = {"access_token": grant, "file": dict(file), "access_level": row["access_level"]}
    if error:
        raise error
    return result


def download_share(token, grant):
    with connection() as c:
        c.execute("BEGIN IMMEDIATE")
        row, file = active_share(c, token)
        auth = c.execute("SELECT * FROM grants WHERE token_hash=? AND share_id=? AND expires_at>?",
                         (hash_token(grant or ""), row["id"], time.time())).fetchone()
        if not auth:
            raise DomainError(401, "Сначала откройте ссылку и проверьте пароль")
        if row["access_level"] != "download":
            raise DomainError(403, "Скачивание запрещено владельцем")
        c.execute("UPDATE share_links SET downloads=downloads+1 WHERE id=?", (row["id"],))
        audit(c, None, "FileDownloaded", file["id"])
        return dict(file)
