"""Build a Russian student lab report with portable embedded Cyrillic fonts."""
import html
import re
import textwrap
import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.platypus import (
    CondPageBreak, Frame, Image, NextPageTemplate, PageBreak,
    PageTemplate, Paragraph, Preformatted, Spacer, Table, TableStyle,
)

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT.parent/'shared'))
from report_style import BODY, SMALL, HEAD, SUB, CAP, CODE, ReportDoc, cover, contents, footer  # noqa: E402


def inline(value):
    value=html.escape(value.replace('—','-'))
    value=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1',value)
    value=re.sub(r'`([^`]+)`',r'<font name="CodeRU">\1</font>',value)
    value=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',value)
    return value


def figure(path,width=17*cm,height=20*cm):
    img=Image(str(path))
    scale=min(width/img.imageWidth,height/img.imageHeight)
    img.drawWidth=img.imageWidth*scale
    img.drawHeight=img.imageHeight*scale
    img.hAlign='CENTER'
    return img


def markdown(text,story):
    lines=text.splitlines()
    i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:
            i+=1
            continue
        if line.startswith('```'):
            block=[]
            i+=1
            while i<len(lines) and not lines[i].startswith('```'):
                block.extend(textwrap.wrap(lines[i],width=88,replace_whitespace=False,drop_whitespace=False) or [''])
                i+=1
            story.append(Preformatted('\n'.join(block),CODE))
            i+=1
            continue
        if line.startswith('!['):
            match=re.search(r'\(([^)]+)\)',line)
            path=ROOT/match[1]
            if path.name=='requirements.png':
                story.append(figure(path,height=10*cm))
                story.append(Spacer(1,8))
                story.append(Paragraph('Рисунок 1 - Модель требований',CAP))
            else:
                story.append(Paragraph('Схема приведена в приложении к отчёту.',BODY))
            i+=1
            continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+',x) for x in cells):
                    rows.append(cells)
                i+=1
            cols=len(rows[0])
            if cols==5:
                widths=[1.6*cm,2.9*cm,2.1*cm,5.2*cm,5.2*cm]
                if rows[0][0]=='Метод':
                    widths=[1.9*cm,7.0*cm,1.7*cm,2.5*cm,3.9*cm]
            elif cols==4:
                widths=[2.1*cm,5.5*cm,2.6*cm,6.8*cm]
            elif cols==3:
                widths=[4.3*cm,5.6*cm,7.1*cm]
            else:
                widths=[4.4*cm,12.6*cm]
            data=[[Paragraph(inline(v),SMALL) for v in row] for row in rows]
            table=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([
                ('LINEABOVE',(0,0),(-1,0),.8,colors.black),
                ('LINEBELOW',(0,0),(-1,0),.5,colors.black),
                ('FONTNAME',(0,0),(-1,0),'TimesRU-Bold'),
                ('LINEBELOW',(0,-1),(-1,-1),.8,colors.black),
                ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
                ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),
                ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),
            ]))
            story.extend([table,Spacer(1,12)])
            continue
        if line.startswith('#'):
            level=len(line)-len(line.lstrip('#'))
            story.append(Paragraph(inline(line.lstrip('#').strip()),HEAD if level==1 else SUB))
            i+=1
            continue
        paragraph=[line]
        i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','![')):
            paragraph.append(lines[i].strip())
            i+=1
        story.append(Paragraph(inline(' '.join(paragraph)),BODY))


def generate():
    portrait=Frame(2.5*cm,1.8*cm,A4[0]-4*cm,A4[1]-3.6*cm,id='portrait',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
    wide=landscape(A4)
    landscape_frame=Frame(2.5*cm,1.8*cm,wide[0]-4*cm,wide[1]-3.6*cm,id='landscape',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
    doc=ReportDoc(str(ROOT/'lab4-report.pdf'),pagesize=A4,
        title='GremlinDrive Лабораторная работа 4',author='Александр Сытин',
        subject='Стили интеграции программных систем и проектирование API')
    doc.addPageTemplates([PageTemplate(id='portrait',frames=[portrait],onPage=footer,pagesize=A4),
                         PageTemplate(id='landscape',frames=[landscape_frame],onPage=footer,pagesize=wide)])
    story=cover(4,'Стили интеграции программных систем и проектирование API')+contents()
    markdown('''# 1 Цель и исходные материалы

В работе спроектированы API и способ подключения AI-ассистента к GremlinDrive. Получен контракт на 52 HTTP-операции, физическая схема PostgreSQL и работающий MCP-прототип. Веб- и мобильный клиенты используют общий серверный контракт, а проверка прав сосредоточена на сервере.

Работа выполнена по методическим указаниям ПЧМИ ЛабРабота4 2026-2027, опубликованным на учебном портале 13 октября 2026 года. Для группы 10 критерии требуют задания 1–5. Дополнительно подготовлены локальная инфраструктура и CI из задания 6.

Входными данными служат SRS, User Stories и модели ЛР3 из коммита 392a849, подготовленные Матвеем Вержбибой. Сохранены роли гостя, пользователя, владельца папки и администратора, а также исходные сущности данных. Новые решения относятся к проектированию, а не к результатам опросов пользователей. UC-01-UC-05 сохраняют исходные значения: загрузка, ссылка, приглашение, восстановление версии и запрос прав или квоты. Дополнительные варианты начинаются с UC-06. Палитра документации и структура отчёта продолжают предыдущие работы.

## 1.1 Выбор способов интеграции

Для веб- и мобильного клиента выбран REST API с JSON. Он позволяет менять сервер и клиенты независимо в пределах версии контракта. Прямое подключение клиента к БД потребовало бы раскрыть структуру таблиц и перенести контроль доступа в несколько мест. Обмен файлами подходит для экспорта, но не для интерактивной работы с правами и состояниями.

Длительные операции загрузки, антивирусной проверки и уведомлений в целевой архитектуре выполняет worker с очередью Redis. MCP добавляет интерфейс для LLM-клиента и повторно использует доменные проверки. Для лабораторного MVP выбраны Python SDK и SQLite, прямо допускаемые заданием; целевой стек NestJS, PostgreSQL и MinIO из ЛР3 не считается реализованным этим прототипом.

## 1.2 Состав комплекта

Модель требований и реестр находятся в requirements.md, маршруты - в api-design.md, контракт - в openapi.json. Схема и SQL-проверки размещены в database, исходники диаграмм - в diagrams, код и тесты - в runtime. Коллекции доступны для Bruno и Postman, протоколы выполнения - в evidence.
''',story)
    for filename,title in [('requirements.md','2 Модель требований и варианты использования'),
                           ('database/logical-model.md','3 Логическая и физическая модели данных'),
                           ('api-design.md','4 Маршруты и контракт API')]:
        story.append(CondPageBreak(6*cm))
        source=(ROOT/filename).read_text()
        source=re.sub(r'^# .*', '# '+title, source,count=1)
        markdown(source,story)
        if filename.startswith('database'):
            markdown('''## Физические ограничения

Выбрана PostgreSQL 16. Идентификаторы имеют тип uuid, время - timestamptz, размер - bigint. В таблицах задано обязательное заполнение, ключи, проверки диапазонов и индексы. Для ссылок действует правило ровно одного адресата: file_id или folder_id. Токены сессий, ссылок и приглашений заменены хешами, пароль хранится отдельно в виде хеша.

Квота не может быть отрицательной или меньше суммы занятого и зарезервированного объёма. В пределах одной папки запрещены одинаковые имена без учёта регистра, включая корневые папки. Составной внешний ключ не позволяет поместить файл в папку другого владельца. Триггер предотвращает циклы папок, а журнал аудита допускает только добавление записей.

Доступ пользователя, резервирование квоты и переходы состояний дополнительно проверяются в транзакциях приложения. Ограничения БД не заменяют авторизацию. При восстановлении версии создаётся новая запись file_versions, а объекты S3 ссылаются на уникальный storage_key. Полная DDL находится в schema.sql; диаграммы физических контекстов приведены в приложении.
''',story)
    story.append(CondPageBreak(6*cm))
    markdown('''# 5 Проверка API и схемы данных

Сначала OpenAPI проверен openapi-spec-validator. Затем все 52 операции вызваны на Prism; успешные JSON-ответы проверены по соответствующим схемам. Некорректный запрос к share-links возвращает 422, пример запрета доступа - 403. Эти проверки подтверждают согласованность контракта и примеров, а бизнес-права отдельно проверяются на stateful mock.

Коллекция Bruno запущена официальным CLI с окружением contract. Результат - 52 успешных запроса и 52 успешных теста. Проверяются статусы ответов. В Postman можно импортировать postman_collection.json с теми же маршрутами и примерами тел.

Pytest выполнил 22 теста REST и MCP. REST и общая доменная логика имеют покрытие 87,50%. Проверены гостевой доступ, пароль, ограничение попыток, истечение и отзыв ссылки, запрет записи для читателя, отсутствие доступа у постороннего, корзина, карантин, однократное решение по квоте и отсутствие секретов в аудите.

Схема SQL применена в чистой PostgreSQL 16.15 внутри Docker. Создано 17 таблиц. Восемь проверок подтвердили ограничения квоты, единственного адресата ссылки, имён папок, внешнего ключа, даты удаления, комментария отказа, циклов папок и изменения аудита. Тестовая транзакция отменена после проверок.

## 5.1 Воспроизведение

```bash
cd docs/labs/lab4/runtime
.venv/bin/pytest -q --cov=store --cov=api
.venv/bin/python check_contract.py
.venv/bin/python test_mcp.py
```

Перед проверкой контракта запускается docker compose up -d api database contract из каталога лабораторной. Для проверки SQL выполняется psql с test_constraints.sql в контейнере database. Для Bruno используется npx --yes @usebruno/cli run --env contract из каталога bruno.

Протоколы pytest.txt, contract-tests.json, postgresql.txt, bruno-summary.json и mcp-protocol.json приложены к работе. Результаты относятся к учебному стенду, а показатели производительности промышленного хранилища не измерялись.
''',story)
    for filename,title in [('mcp.md','6 Проектирование и реализация MCP'),('infrastructure.md','7 Инфраструктура и организация работы')]:
        story.append(CondPageBreak(6*cm))
        markdown(re.sub(r'^# .*','# '+title,(ROOT/filename).read_text(),count=1),story)
    story.append(CondPageBreak(6*cm))
    markdown('''# 8 Результат работы

Требования ЛР3 связаны с 19 вариантами использования и 52 операциями API. Подготовлены логическая модель, физическая PostgreSQL-схема и исполняемые проверки ограничений. Запросы доступны в OpenAPI, Bruno и Postman. MCP-сервер предоставляет семь инструментов, три ресурса, один шаблон ресурса и два промпта и проходит проверку по реальному stdio-протоколу.

ЛР4 подготовил Александр Сытин. Исходные модели ЛР3 подготовил Матвей Вержбиба; его коммит сохранён. Для демонстрации доступны контейнеры API, Prism, PostgreSQL и web. Облачный backend, подключение SonarCloud и промышленная реализация интеграций остаются следующим этапом.

## Источники

Методические указания ПЧМИ ЛабРабота4 2026-2027, образовательный портал ФПМИ БГУ, задание 36176.

GremlinDrive. SRS, User Stories и диаграммы ЛР3, коммит 392a849, репозиторий fpmi-hci-2026/hci-10-project-group-4.

OpenAPI Specification 3.1.2. https://spec.openapis.org/oas/v3.1.html

Официальный Python SDK Model Context Protocol. https://github.com/modelcontextprotocol/python-sdk

Официальный MCP Inspector. https://modelcontextprotocol.io/docs/tools/inspector

Материалы из методических указаний: Особенности проектирования MCP-сервера и Пример реализации MCP-сервера, babok-school.ru.
''',story)
    for number,(template,title,filename) in enumerate([
       ('landscape','Приложение А Физическая модель пользователей и управления','physical-identity.png'),
       ('portrait','Приложение Б Физическая модель файлов и загрузки','physical-storage.png'),
       ('landscape','Приложение В Физическая модель общего доступа','physical-sharing.png'),
       ('landscape','Приложение Г Архитектура MCP','mcp.png'),
       ('landscape','Приложение Д Инфраструктура лабораторного стенда','infrastructure.png')],2):
        story.extend([NextPageTemplate(template),PageBreak(),Paragraph(title,HEAD)])
        width,height=(wide if template=='landscape' else A4)
        story.append(figure(ROOT/'diagrams'/filename,width-4.5*cm,height-7.5*cm))
        story.append(Spacer(1,10))
        story.append(Paragraph(f'Рисунок {number} - '+title.split(' ',2)[2]+'. Исходник находится в diagrams.',CAP))
    doc.multiBuild(story)
    print(ROOT/'lab4-report.pdf')


if __name__=='__main__':
    generate()
