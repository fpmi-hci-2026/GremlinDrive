# GremlinDrive: исходники ЛР4

- `backend/` — FastAPI mock, MCP, PostgreSQL, Bruno, тесты и CI.
- `docs/` — требования, логическая и физическая модели, диаграммы, OpenAPI, доказательства и исходники отчёта.

Запуск API и MCP: см. `backend/README.md`.
Отчёт: `docs/report/report.tex` (LuaLaTeX).
