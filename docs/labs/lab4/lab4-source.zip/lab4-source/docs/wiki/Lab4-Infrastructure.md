# Инфраструктура и проверки

## Локальный стенд

Docker Compose поднимает stateful API, Prism и PostgreSQL. API и PostgreSQL имеют healthcheck. Порты API и mock привязаны к `127.0.0.1`, PostgreSQL не публикуется на хосте. SQLite и PostgreSQL используют разные volumes. Сервисы не обращаются к реальным файлам пользователя.

![Инфраструктура](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/diagrams/infrastructure.png)

Приложение в Dockerfile работает от непривилегированного пользователя. Для остановки используется `docker compose down`; данные остаются в volumes.

## Непрерывная интеграция

Workflow `lab4.yml` в backend-репозитории запускает Ruff, pytest с порогом покрытия 70%, генерирует OpenAPI из исходников и валидирует документ. Только после тестов строится Docker-образ. Затем выполняются проверки PostgreSQL, всех операций Prism, коллекции Bruno и MCP через SDK и официальный Inspector. Протоколы сохраняются как GitHub Actions artifact.

## Репозитории

| Репозиторий | Содержимое |
|---|---|
| [hci-10-project-group-4](https://github.com/fpmi-hci-2026/hci-10-project-group-4) | Документация, отчёты, диаграммы, данные и страницы |
| [hci-10-backend-api-group-3](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3) | API, MCP, PostgreSQL, Bruno, тесты и CI |
| [hci-10-frontend-group-3](https://github.com/fpmi-hci-2026/hci-10-frontend-group-3) | Веб- и мобильный прототип ЛР5 |

## Вклад участников

Матвей Вержбицкий --- требования, варианты использования, логическая модель, проверка преемственности и ревью. Александр Сытин --- физическая модель, OpenAPI, stateful mock, MCP, тесты, CI и оформление. Контракт и итоговый комплект согласованы совместно.

## Проверка при защите

Сначала открыть PDF и страницу лабораторной. Показать связь US-03 → UC-02 → `POST share-links`, затем логическую и физическую модели и `schema.sql`. В Bruno запустить окружение `contract`, в Swagger mock показать запрет публикации для читателя и успешное создание ссылки владельцем. Через Inspector показать `tools/list`, ресурс `gremlin://policy` и вызов `list_files`. В конце открыть протоколы тестов и workflow CI.
