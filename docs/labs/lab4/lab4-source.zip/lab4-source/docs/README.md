# Лабораторная работа 4

GremlinDrive. Стили интеграции программных систем и проектирование API. Работа продолжает требования и модели ЛР3, подготовленные Матвеем Вержбицким в коммите 392a849. В ЛР4 уточнены требования к API, логическая и физическая модели данных, контракт запросов, mock-окружение и MCP MVP.

Код, тесты и конфигурация стенда находятся в отдельном репозитории [hci-10-backend-api-group-3](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3).

## Материалы

| Задание | Результат |
|---|---|
| 1 | [Модель требований и 19 вариантов использования](requirements.md), [трассировка](traceability.json) |
| 2 | [Логическая модель](database/logical-model.md), [PostgreSQL DDL](database/schema.sql), [PlantUML](diagrams) |
| 3 | [Маршруты и их связь с UC](api-design.md), [OpenAPI](openapi.json) |
| 4 | [Коллекция Bruno](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3/tree/main/bruno), [коллекция Postman](postman_collection.json), [проверки контракта](evidence/contract-tests.json) |
| 5 | [Описание MCP](mcp.md), [исходники и запуск](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3/tree/main/runtime), [JSON-схемы и протокол](evidence/mcp-protocol.json) |
| 6 | [Инфраструктура и план](infrastructure.md), [Compose](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3/blob/main/compose.yaml), [CI](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3/blob/main/.github/workflows/lab4.yml) |

[Отчёт PDF](lab4-report.pdf). [Материалы на сайте проекта](https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/).

## Запуск и проверки

Инструкции по запуску API, MCP, Bruno и Docker Compose находятся в [README backend-репозитория](https://github.com/fpmi-hci-2026/hci-10-backend-api-group-3#readme).

## Демонстрационные данные

У mock-сервиса есть публичные учебные токены `lab-owner-token`, `lab-reader-token`, `lab-admin-token` и `lab-outsider-token`. Они предназначены только для изолированного стенда с тестовыми данными. Владельцу принадлежит папка «Учёба» и файл «Лабораторная.txt», читатель имеет доступ на просмотр. Секреты портала, GitHub и реальные файлы пользователей стенд не использует.

## Границы результата

OpenAPI описывает 52 операции. Из них 21 работает с состоянием SQLite, остальные симулируются Prism. Регистрация, TOTP, S3, передача бинарных частей, SMTP, LDAP и push описаны контрактом для следующего этапа. MCP MVP реализован и проверен в своей заявленной области из семи инструментов, трёх ресурсов, одного шаблона ресурса и двух промптов.

Задание 6 выполнено в части локального стенда, Dockerfile, Compose, автоматических тестов, генерации OpenAPI и workflow CI. Публикация backend в облаке и подключение SonarCloud требуют отдельных аккаунтов и настроек сервиса.
