# GremlinDrive Backend API

Серверная часть учебного проекта GremlinDrive: REST API, MCP-сервер, PostgreSQL-схема и проверки контракта для лабораторной работы №4 по курсу «Проектирование человеко-машинных интерфейсов».

## Состав

| Каталог | Назначение |
|---|---|
| `runtime/` | FastAPI stateful mock, SQLite-хранилище, MCP-сервер и тесты |
| `database/` | Физическая схема PostgreSQL и проверки ограничений |
| `bruno/` | Коллекция Bruno для проверки контракта |
| `openapi.json` | Сгенерированный контракт API |
| `postman_collection.json` | Коллекция Postman |
| `compose.yaml` | Локальный стенд API, Prism и PostgreSQL |

Документация, отчёты и опубликованные страницы находятся в основном репозитории `hci-10-project-group-4`. Веб-прототип — в репозитории `hci-10-frontend-group-3`.

## Требования

- Python 3.12
- Docker и Docker Compose (для контейнерного стенда)
- Node.js 22 и npx (для Bruno и MCP Inspector)

## Запуск API и MCP

```bash
cd runtime
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/pytest -q --cov=store --cov=api
.venv/bin/python test_mcp.py
.venv/bin/uvicorn api:app --host 127.0.0.1 --port 8044
```

MCP-сервер запускается по stdio:

```bash
cd runtime
GREMLIN_USER_ID=00000000-0000-4000-8000-000000000001 .venv/bin/python mcp_server.py
```

`GREMLIN_USER_ID` задаёт учебного пользователя. Без переменной сервер не должен работать от владельца по умолчанию — это ограничение будет исправлено в рамках переработки ЛР4.

## Контракт и Bruno

```bash
cd runtime
.venv/bin/python build_contract.py
.venv/bin/python check_contract.py
cd ../bruno
npx --yes @usebruno/cli run --env contract
```

`check_contract.py` проверяет ответы Prism по схемам OpenAPI. Для запуска Prism используется `compose.yaml`.

## Docker Compose

```bash
docker compose up -d --build api database contract
```

- API: http://127.0.0.1:8044/docs
- Prism: http://127.0.0.1:4010
- PostgreSQL: внутри сети Compose

## Проверки

```bash
cd runtime
.venv/bin/ruff check . --config pyproject.toml
.venv/bin/pytest -q --cov=store --cov=api --cov-fail-under=70
```

## Ссылки

- Основной репозиторий: https://github.com/fpmi-hci-2026/hci-10-project-group-4
- Frontend: https://github.com/fpmi-hci-2026/hci-10-frontend-group-3
- Сайт: https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab4/
