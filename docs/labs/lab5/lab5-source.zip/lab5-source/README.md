# GremlinDrive: исходники ЛР5

- `frontend/prototype/` — интерактивный прототип.
- `docs/lab5/` — данные, снимки, руководство по стилю, исходники отчёта и PDF.

Запуск: `cd frontend/prototype && python3 -m http.server 8056`.
Тестовый вход: `student@example.test` / `gremlin2026`. Гостевая ссылка: `laboratory123`.
