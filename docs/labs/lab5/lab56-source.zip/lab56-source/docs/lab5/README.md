# Лабораторная работа 5: прототип GremlinDrive

Работа продолжает исходные ЛР1–2 команды и SRS ЛР3 (392a849). Преемственность описана в [CONTINUITY.md](../CONTINUITY.md). Палитра #2E9E62, Inter, навигация и базовые UC сохранены; для кнопок выбран тёмный зелёный #1F7A4B.

[Отчёт PDF](lab5-report.pdf), [исходник отчёта](report/report.tex). Исходники прототипа находятся в отдельном репозитории [hci-10-frontend-group-3](https://github.com/fpmi-hci-2026/hci-10-frontend-group-3/tree/main/prototype).

Публичный прототип: https://fpmi-hci-2026.github.io/GremlinDrive/labs/lab5/prototype/. Параметры: `mobile=1`, `theme=brand|contrast|emerald`, `screen=files&folder=course`, `grid=1`. Тестовый вход: `student@example.test` / `gremlin2026`. Демонстрационная гостевая ссылка использует пароль `laboratory123`. Реальной авторизации и передачи файлов нет, в `localStorage` остаются демонстрационные метаданные.

Оценки 15 профилей смоделированы, а не получены от людей. `data/semantic.csv` содержит 1350 значений; происхождение и зерно 20261024 зафиксированы в `data/PROVENANCE.json`. Реальных участников не было.

В `assets` находятся 6 веб-раскладок, 5 mobile/tablet-устройств, 3 палитры на двух платформах, семантический профиль, сценарии и руководство по стилю. Руководство по стилю: `prototype/styleguide.html` в frontend-репозитории и на публичной странице прототипа.
