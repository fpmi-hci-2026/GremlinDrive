# GremlinDrive: исходники ЛР5–6

- `frontend/prototype/` — интерактивный прототип ЛР5.
- `docs/lab5/` — данные, снимки, исходники отчёта и README.
- `docs/lab6/` — данные, анкеты и исходники ЛР6.

Прототип запускается из `frontend/prototype` командой `python3 -m http.server 8056`.
